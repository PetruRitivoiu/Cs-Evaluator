﻿namespace DemoProiectPAW
{
    interface IDemoTesting
    {
        string GetShortFileName(string filename);
        bool IsURLValid(string url);
    }
}
